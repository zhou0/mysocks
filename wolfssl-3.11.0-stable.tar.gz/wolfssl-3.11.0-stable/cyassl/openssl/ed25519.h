/* ed25519.h  */

#include <wolfssl/openssl/ed25519.h>
